import React from "react";
import { Facebook, Instagram, Twitter, Mail, Phone, MapPin } from "lucide-react";
import { motion } from "motion/react";

export function Footer() {
  return (
    <footer className="bg-gradient-to-br from-gray-900 to-black border-t border-green-500/20 mt-20">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo e descrição */}
          <div>
            <h2 className="bg-gradient-to-r from-green-400 via-emerald-500 to-green-600 bg-clip-text text-transparent mb-4">
              🌿 GreenMarket
            </h2>
            <p className="text-gray-400 text-sm mb-4">
              A melhor loja online de produtos canábicos premium. Qualidade, segurança e discrição.
            </p>
            <div className="flex gap-3">
              <motion.a
                whileHover={{ scale: 1.1, y: -2 }}
                href="#"
                className="p-2 bg-gray-800 rounded-full hover:bg-green-600 transition-colors"
              >
                <Instagram className="size-4" />
              </motion.a>
              <motion.a
                whileHover={{ scale: 1.1, y: -2 }}
                href="#"
                className="p-2 bg-gray-800 rounded-full hover:bg-green-600 transition-colors"
              >
                <Facebook className="size-4" />
              </motion.a>
              <motion.a
                whileHover={{ scale: 1.1, y: -2 }}
                href="#"
                className="p-2 bg-gray-800 rounded-full hover:bg-green-600 transition-colors"
              >
                <Twitter className="size-4" />
              </motion.a>
            </div>
          </div>

          {/* Links rápidos */}
          <div>
            <h3 className="text-green-400 mb-4">Links Rápidos</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#" className="hover:text-green-400 transition-colors">Sobre Nós</a></li>
              <li><a href="#" className="hover:text-green-400 transition-colors">Produtos</a></li>
              <li><a href="#" className="hover:text-green-400 transition-colors">Blog</a></li>
              <li><a href="#" className="hover:text-green-400 transition-colors">FAQ</a></li>
            </ul>
          </div>

          {/* Suporte */}
          <div>
            <h3 className="text-green-400 mb-4">Suporte</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#" className="hover:text-green-400 transition-colors">Central de Ajuda</a></li>
              <li><a href="#" className="hover:text-green-400 transition-colors">Política de Privacidade</a></li>
              <li><a href="#" className="hover:text-green-400 transition-colors">Termos de Uso</a></li>
              <li><a href="#" className="hover:text-green-400 transition-colors">Trocas e Devoluções</a></li>
            </ul>
          </div>

          {/* Contato */}
          <div>
            <h3 className="text-green-400 mb-4">Contato</h3>
            <ul className="space-y-3 text-sm text-gray-400">
              <li className="flex items-center gap-2">
                <Mail className="size-4 text-green-500" />
                contato@greenmarket.com.br
              </li>
              <li className="flex items-center gap-2">
                <Phone className="size-4 text-green-500" />
                (11) 99999-9999
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="size-4 text-green-500 mt-0.5" />
                <span>São Paulo, SP<br />Brasil</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-500">
          <p>© 2024 GreenMarket. Todos os direitos reservados.</p>
          <p className="mt-2 text-xs">
            Este site é apenas uma demonstração. Verifique as leis locais sobre produtos canábicos.
          </p>
        </div>
      </div>
    </footer>
  );
}
