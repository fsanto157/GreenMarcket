import React from "react";
import { motion } from "motion/react";
import { Loader2 } from "lucide-react";

interface ButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "outline" | "ghost";
  size?: "sm" | "md" | "lg";
  disabled?: boolean;
  loading?: boolean;
  className?: string;
  type?: "button" | "submit" | "reset";
}

export function Button({
  children,
  onClick,
  variant = "primary",
  size = "md",
  disabled = false,
  loading = false,
  className = "",
  type = "button",
}: ButtonProps) {
  const baseClasses = "rounded-xl transition-all border inline-flex items-center justify-center gap-2";
  
  const variantClasses = {
    primary: "bg-gradient-to-r from-green-600 to-emerald-600 shadow-lg shadow-green-500/30 hover:shadow-green-500/50 border-green-500/30 text-white",
    secondary: "bg-gradient-to-r from-yellow-500 to-yellow-600 shadow-lg shadow-yellow-500/30 hover:shadow-yellow-500/50 border-yellow-500/30 text-black",
    outline: "bg-transparent border-green-500/50 hover:bg-green-500/10 text-green-400",
    ghost: "bg-gray-800 border-gray-700 hover:border-green-500/50 hover:bg-gray-700 text-white",
  };

  const sizeClasses = {
    sm: "px-3 py-1.5 text-sm",
    md: "px-6 py-2.5",
    lg: "px-8 py-4",
  };

  const disabledClasses = disabled || loading
    ? "opacity-50 cursor-not-allowed"
    : "cursor-pointer";

  return (
    <motion.button
      whileHover={disabled || loading ? {} : { scale: 1.02 }}
      whileTap={disabled || loading ? {} : { scale: 0.98 }}
      onClick={disabled || loading ? undefined : onClick}
      disabled={disabled || loading}
      type={type}
      className={`${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${disabledClasses} ${className}`}
    >
      {loading && <Loader2 className="size-4 animate-spin" />}
      {children}
    </motion.button>
  );
}
