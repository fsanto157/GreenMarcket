import React from "react";
import { motion } from "motion/react";
import { Heart, Star, ShoppingCart } from "lucide-react";
import { Button } from "./Button";

interface Product {
  id: number;
  nome: string;
  preco: number;
  categoria: string;
  img: string;
  rating: number;
  reviews: number;
  thc: string;
  cbd: string;
  stock?: number;
}

interface ProductCardProps {
  product: Product;
  isInWishlist: boolean;
  onToggleWishlist: (id: number) => void;
  onAddToCart: (product: Product) => void;
  onViewDetails: (product: Product) => void;
  index: number;
}

export function ProductCard({
  product,
  isInWishlist,
  onToggleWishlist,
  onAddToCart,
  onViewDetails,
  index,
}: ProductCardProps) {
  const isOutOfStock = product.stock !== undefined && product.stock === 0;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      whileHover={{ y: -5 }}
      className={`group relative bg-gradient-to-br from-gray-900 to-black rounded-2xl overflow-hidden border border-green-500/10 hover:border-green-500/30 shadow-xl hover:shadow-green-500/20 transition-all ${
        isOutOfStock ? "opacity-60" : ""
      }`}
    >
      {/* Out of Stock Badge */}
      {isOutOfStock && (
        <div className="absolute top-3 left-3 z-10 bg-red-500 text-white px-3 py-1 rounded-full text-xs">
          Esgotado
        </div>
      )}

      {/* Wishlist button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => onToggleWishlist(product.id)}
        className="absolute top-3 right-3 z-10 bg-black/70 backdrop-blur-sm p-2 rounded-full border border-green-500/30"
      >
        <Heart
          className={`size-5 ${
            isInWishlist ? "fill-red-500 text-red-500" : "text-gray-400"
          }`}
        />
      </motion.button>

      {/* Image */}
      <div
        className="relative h-64 overflow-hidden cursor-pointer"
        onClick={() => onViewDetails(product)}
      >
        <img
          src={product.img}
          alt={product.nome}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60" />
      </div>

      <div className="p-5">
        {/* Rating */}
        <div className="flex items-center gap-2 mb-2">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`size-4 ${
                  i < Math.floor(product.rating)
                    ? "fill-yellow-400 text-yellow-400"
                    : "text-gray-600"
                }`}
              />
            ))}
          </div>
          <span className="text-xs text-gray-400">({product.reviews})</span>
        </div>

        <h3
          className="mb-2 cursor-pointer hover:text-green-400 transition-colors"
          onClick={() => onViewDetails(product)}
        >
          {product.nome}
        </h3>

        <div className="flex items-baseline gap-2 mb-4">
          <span className="bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
            R$ {product.preco.toFixed(2)}
          </span>
          {product.thc !== "-" && (
            <span className="text-xs text-gray-500">THC {product.thc}</span>
          )}
        </div>

        <div className="flex gap-2">
          <Button
            onClick={() => onAddToCart(product)}
            disabled={isOutOfStock}
            className="flex-1"
          >
            <ShoppingCart className="size-4" />
            {isOutOfStock ? "Esgotado" : "Adicionar"}
          </Button>
          <Button onClick={() => onViewDetails(product)} variant="ghost" size="md">
            Ver
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
