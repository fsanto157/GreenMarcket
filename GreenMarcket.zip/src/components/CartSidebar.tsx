import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Plus, Minus, ShoppingCart } from "lucide-react";
import { Button } from "./Button";

interface CartItem {
  id: number;
  nome: string;
  preco: number;
  img: string;
  quantidade: number;
}

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (id: number, delta: number) => void;
  onCheckout: () => void;
}

export function CartSidebar({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onCheckout,
}: CartSidebarProps) {
  const total = cart.reduce((sum, item) => sum + item.preco * item.quantidade, 0);
  const totalItems = cart.reduce((sum, item) => sum + item.quantidade, 0);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
          />
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 25 }}
            className="fixed right-0 top-0 h-full w-full max-w-md bg-gradient-to-br from-gray-900 to-black border-l border-green-500/20 z-50 flex flex-col shadow-2xl"
          >
            {/* Header */}
            <div className="p-6 border-b border-green-500/20">
              <div className="flex items-center justify-between">
                <h2 className="bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
                  Carrinho ({totalItems})
                </h2>
                <motion.button
                  whileHover={{ scale: 1.1, rotate: 90 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={onClose}
                  className="p-2 hover:bg-gray-800 rounded-full"
                >
                  <X className="size-6" />
                </motion.button>
              </div>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto p-6">
              {cart.length === 0 ? (
                <div className="text-center text-gray-500 mt-12">
                  <ShoppingCart className="size-16 mx-auto mb-4 opacity-20" />
                  <p>Carrinho vazio</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {cart.map((item) => (
                    <motion.div
                      key={item.id}
                      layout
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="flex gap-4 bg-gray-800/50 p-4 rounded-xl border border-green-500/10"
                    >
                      <img
                        src={item.img}
                        alt={item.nome}
                        className="w-20 h-20 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm mb-2">{item.nome}</h3>
                        <p className="text-green-400 text-sm mb-2">
                          R$ {item.preco.toFixed(2)}
                        </p>
                        <div className="flex items-center gap-2">
                          <motion.button
                            whileTap={{ scale: 0.9 }}
                            onClick={() => onUpdateQuantity(item.id, -1)}
                            className="p-1 bg-gray-700 rounded hover:bg-gray-600"
                          >
                            <Minus className="size-4" />
                          </motion.button>
                          <span className="w-8 text-center">{item.quantidade}</span>
                          <motion.button
                            whileTap={{ scale: 0.9 }}
                            onClick={() => onUpdateQuantity(item.id, 1)}
                            className="p-1 bg-gray-700 rounded hover:bg-gray-600"
                          >
                            <Plus className="size-4" />
                          </motion.button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            {cart.length > 0 && (
              <div className="p-6 border-t border-green-500/20 bg-black">
                <div className="flex justify-between mb-4">
                  <span className="text-gray-400">Total</span>
                  <span className="bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
                    R$ {total.toFixed(2)}
                  </span>
                </div>
                <Button onClick={onCheckout} className="w-full" size="lg">
                  Finalizar Compra
                </Button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
