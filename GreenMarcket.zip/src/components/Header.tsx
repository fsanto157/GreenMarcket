import React from "react";
import { motion } from "motion/react";
import { ShoppingCart, Heart, Search, User, LogOut } from "lucide-react";

interface HeaderProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  cartItemsCount: number;
  wishlistCount: number;
  onCartClick: () => void;
  onWishlistClick: () => void;
  onNavigate: (page: string) => void;
  currentUser: { name: string; email: string } | null;
  onLogout: () => void;
}

export function Header({
  searchTerm,
  setSearchTerm,
  cartItemsCount,
  wishlistCount,
  onCartClick,
  onWishlistClick,
  onNavigate,
  currentUser,
  onLogout,
}: HeaderProps) {
  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="sticky top-0 z-50 bg-gradient-to-r from-black via-gray-900 to-black border-b border-green-500/20 backdrop-blur-xl"
    >
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          {/* Logo */}
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="cursor-pointer"
            onClick={() => onNavigate("home")}
          >
            <h1 className="bg-gradient-to-r from-green-400 via-emerald-500 to-green-600 bg-clip-text text-transparent drop-shadow-[0_0_20px_rgba(34,197,94,0.5)]">
              🌿 GreenMarket
            </h1>
          </motion.div>

          {/* Search */}
          <div className="flex-1 max-w-md relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-green-500 size-5" />
            <input
              type="text"
              placeholder="Buscar produtos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-gray-900/50 border border-green-500/30 rounded-full pl-11 pr-4 py-2 text-sm focus:outline-none focus:border-green-500 focus:ring-2 focus:ring-green-500/20"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            {/* Wishlist */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onWishlistClick}
              className="relative p-2 hover:bg-gray-800 rounded-full"
            >
              <Heart className="size-5 text-green-400" />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full size-5 flex items-center justify-center text-xs">
                  {wishlistCount}
                </span>
              )}
            </motion.button>

            {/* Cart */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onCartClick}
              className="relative bg-gradient-to-r from-green-600 to-emerald-600 px-4 sm:px-6 py-2 rounded-full shadow-lg shadow-green-500/50 border border-green-400/30"
            >
              <ShoppingCart className="inline size-5 sm:mr-2" />
              <span className="hidden sm:inline">Carrinho</span>
              {cartItemsCount > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-2 -right-2 bg-gradient-to-r from-yellow-400 to-yellow-600 text-black rounded-full size-6 flex items-center justify-center text-xs shadow-lg shadow-yellow-500/50"
                >
                  {cartItemsCount}
                </motion.span>
              )}
            </motion.button>

            {/* User */}
            {currentUser ? (
              <div className="relative group">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  className="p-2 bg-gray-800 rounded-full border border-green-500/30"
                  onClick={() => onNavigate("perfil")}
                >
                  <User className="size-5 text-green-400" />
                </motion.button>
                <div className="absolute right-0 mt-2 w-48 bg-gray-900 border border-green-500/20 rounded-xl p-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                  <div className="px-3 py-2 border-b border-gray-700 mb-2">
                    <p className="text-sm truncate">{currentUser.name}</p>
                    <p className="text-xs text-gray-400 truncate">{currentUser.email}</p>
                  </div>
                  <button
                    onClick={() => onNavigate("perfil")}
                    className="w-full text-left px-3 py-2 text-sm hover:bg-gray-800 rounded"
                  >
                    Meu Perfil
                  </button>
                  <button
                    onClick={onLogout}
                    className="w-full text-left px-3 py-2 text-sm hover:bg-gray-800 rounded text-red-400 flex items-center gap-2"
                  >
                    <LogOut className="size-4" />
                    Sair
                  </button>
                </div>
              </div>
            ) : (
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => onNavigate("login")}
                className="px-4 py-2 bg-gray-800 rounded-full border border-green-500/30 hover:border-green-500/50 text-sm"
              >
                Entrar
              </motion.button>
            )}
          </div>
        </div>
      </div>
    </motion.header>
  );
}
