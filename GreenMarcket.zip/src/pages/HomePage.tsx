import React, { useState } from "react";
import { motion } from "motion/react";
import { ProductCard } from "../components/ProductCard";
import { Produto } from "../App";
import { Sparkles, TrendingUp, ShieldCheck } from "lucide-react";

interface HomePageProps {
  produtos: Produto[];
  searchTerm: string;
  wishlist: number[];
  onToggleWishlist: (id: number) => void;
  onAddToCart: (produto: Produto) => void;
  onViewProduct: (produto: Produto) => void;
}

export function HomePage({
  produtos,
  searchTerm,
  wishlist,
  onToggleWishlist,
  onAddToCart,
  onViewProduct,
}: HomePageProps) {
  const [filter, setFilter] = useState("all");

  const categorias = [
    { id: "all", nome: "Todos" },
    { id: "flores", nome: "Flores" },
    { id: "vaporizadores", nome: "Vapes" },
    { id: "acessorios", nome: "Acessórios" },
    { id: "oleos", nome: "Óleos" },
    { id: "comestiveis", nome: "Comestíveis" },
  ];

  const produtosFiltrados = produtos
    .filter((p) => (filter === "all" ? true : p.categoria === filter))
    .filter((p) => p.nome.toLowerCase().includes(searchTerm.toLowerCase()));

  const bestSellers = produtos.filter((p) => p.rating >= 4.8).slice(0, 4);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-7xl mx-auto px-4 py-8"
    >
      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative bg-gradient-to-r from-green-900/30 via-emerald-900/20 to-green-900/30 rounded-3xl overflow-hidden mb-12 border border-green-500/20"
      >
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?auto=format&fit=crop&w=1920&q=80')] bg-cover bg-center opacity-10" />
        <div className="relative p-12 md:p-16 text-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <h2 className="mb-4 bg-gradient-to-r from-green-400 via-emerald-500 to-green-600 bg-clip-text text-transparent">
              Produtos Premium de Cannabis
            </h2>
            <p className="text-gray-300 max-w-2xl mx-auto mb-8">
              Qualidade excepcional, discrição garantida e entrega rápida. Explore nosso catálogo
              completo de flores, óleos, vapes e acessórios premium.
            </p>
            <div className="flex flex-wrap justify-center gap-8">
              <div className="flex items-center gap-2">
                <ShieldCheck className="size-5 text-green-400" />
                <span className="text-sm">100% Seguro</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="size-5 text-green-400" />
                <span className="text-sm">Melhor Qualidade</span>
              </div>
              <div className="flex items-center gap-2">
                <Sparkles className="size-5 text-green-400" />
                <span className="text-sm">Produtos Premium</span>
              </div>
            </div>
          </motion.div>
        </div>
      </motion.div>

      {/* Best Sellers */}
      {!searchTerm && filter === "all" && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h2 className="mb-6 text-green-400">🔥 Mais Vendidos</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {bestSellers.map((product, index) => (
              <ProductCard
                key={product.id}
                product={product}
                isInWishlist={wishlist.includes(product.id)}
                onToggleWishlist={onToggleWishlist}
                onAddToCart={onAddToCart}
                onViewDetails={onViewProduct}
                index={index}
              />
            ))}
          </div>
        </motion.div>
      )}

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex gap-3 mb-8 overflow-x-auto pb-2 scrollbar-hide"
      >
        {categorias.map((c) => (
          <motion.button
            key={c.id}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setFilter(c.id)}
            className={`px-6 py-2 rounded-full border whitespace-nowrap transition-all ${
              filter === c.id
                ? "bg-gradient-to-r from-green-500 to-emerald-600 border-green-400 shadow-lg shadow-green-500/50"
                : "border-gray-700 bg-gray-900/50 hover:border-green-500/50"
            }`}
          >
            {c.nome}
          </motion.button>
        ))}
      </motion.div>

      {/* Products Grid */}
      <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {produtosFiltrados.map((product, index) => (
          <ProductCard
            key={product.id}
            product={product}
            isInWishlist={wishlist.includes(product.id)}
            onToggleWishlist={onToggleWishlist}
            onAddToCart={onAddToCart}
            onViewDetails={onViewProduct}
            index={index}
          />
        ))}
      </motion.div>

      {produtosFiltrados.length === 0 && (
        <div className="text-center py-20 text-gray-500">
          <p>Nenhum produto encontrado</p>
        </div>
      )}
    </motion.div>
  );
}
