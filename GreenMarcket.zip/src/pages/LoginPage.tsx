import React, { useState } from "react";
import { motion } from "motion/react";
import { ArrowLeft, Mail, Lock, User, Phone } from "lucide-react";
import { Input } from "../components/Input";
import { Button } from "../components/Button";

interface LoginPageProps {
  onLogin: (userData: any) => void;
  onBack: () => void;
}

export function LoginPage({ onLogin, onBack }: LoginPageProps) {
  const [isRegister, setIsRegister] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    name: "",
    phone: "",
    cpf: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  function updateField(field: string, value: string) {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }));
    }
  }

  function validateForm() {
    const newErrors: Record<string, string> = {};

    if (!formData.email.includes("@")) newErrors.email = "Email inválido";
    if (formData.password.length < 6) newErrors.password = "Senha deve ter no mínimo 6 caracteres";

    if (isRegister) {
      if (!formData.name.trim()) newErrors.name = "Nome é obrigatório";
      if (!formData.phone) newErrors.phone = "Telefone é obrigatório";
      if (!formData.cpf) newErrors.cpf = "CPF é obrigatório";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (validateForm()) {
      setLoading(true);
      setTimeout(() => {
        onLogin({
          name: isRegister ? formData.name : formData.email.split("@")[0],
          email: formData.email,
          phone: formData.phone || "(11) 99999-9999",
          cpf: formData.cpf || "000.000.000-00",
        });
        setLoading(false);
      }, 1500);
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-md mx-auto px-4 py-12"
    >
      <button onClick={onBack} className="mb-6 text-green-400 hover:text-green-300 flex items-center gap-2">
        <ArrowLeft className="size-5" />
        Voltar
      </button>

      <div className="bg-gray-900/50 p-8 rounded-2xl border border-green-500/20">
        <h1 className="mb-2 text-center bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
          {isRegister ? "Criar Conta" : "Entrar"}
        </h1>
        <p className="text-center text-gray-400 text-sm mb-8">
          {isRegister
            ? "Preencha os dados abaixo para criar sua conta"
            : "Entre com seu email e senha"}
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegister && (
            <>
              <Input
                label="Nome Completo"
                value={formData.name}
                onChange={(v) => updateField("name", v)}
                error={errors.name}
                icon={<User className="size-5" />}
                required
              />
              <Input
                label="CPF"
                value={formData.cpf}
                onChange={(v) => updateField("cpf", v)}
                error={errors.cpf}
                placeholder="000.000.000-00"
                required
              />
              <Input
                label="Telefone"
                value={formData.phone}
                onChange={(v) => updateField("phone", v)}
                error={errors.phone}
                icon={<Phone className="size-5" />}
                placeholder="(11) 99999-9999"
                required
              />
            </>
          )}

          <Input
            label="Email"
            type="email"
            value={formData.email}
            onChange={(v) => updateField("email", v)}
            error={errors.email}
            icon={<Mail className="size-5" />}
            required
          />

          <Input
            label="Senha"
            type="password"
            value={formData.password}
            onChange={(v) => updateField("password", v)}
            error={errors.password}
            icon={<Lock className="size-5" />}
            required
          />

          <Button type="submit" loading={loading} className="w-full" size="lg">
            {isRegister ? "Criar Conta" : "Entrar"}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => setIsRegister(!isRegister)}
            className="text-sm text-green-400 hover:text-green-300"
          >
            {isRegister ? "Já tem uma conta? Entrar" : "Não tem uma conta? Criar conta"}
          </button>
        </div>

        {!isRegister && (
          <div className="mt-4 text-center">
            <button className="text-sm text-gray-400 hover:text-gray-300">
              Esqueceu sua senha?
            </button>
          </div>
        )}
      </div>

      <p className="text-xs text-gray-500 text-center mt-6">
        Ao criar uma conta, você concorda com nossos Termos de Uso e Política de Privacidade
      </p>
    </motion.div>
  );
}
