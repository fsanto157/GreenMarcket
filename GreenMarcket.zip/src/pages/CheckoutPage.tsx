import React, { useState } from "react";
import { motion } from "motion/react";
import { ArrowLeft, CreditCard, Wallet } from "lucide-react";
import { Input } from "../components/Input";
import { Button } from "../components/Button";

interface CartItem {
  id: number;
  nome: string;
  preco: number;
  img: string;
  quantidade: number;
}

interface CheckoutPageProps {
  cart: CartItem[];
  onPlaceOrder: (orderData: any) => void;
  onBack: () => void;
}

export function CheckoutPage({ cart, onPlaceOrder, onBack }: CheckoutPageProps) {
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    telefone: "",
    cpf: "",
    cep: "",
    rua: "",
    numero: "",
    complemento: "",
    bairro: "",
    cidade: "",
    estado: "",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [paymentMethod, setPaymentMethod] = useState<"pix" | "card">("pix");
  const [loading, setLoading] = useState(false);

  const subtotal = cart.reduce((sum, item) => sum + item.preco * item.quantidade, 0);
  const frete = subtotal > 150 ? 0 : 15.9;
  const total = subtotal + frete;

  function updateField(field: string, value: string) {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }));
    }
  }

  async function handleCEPBlur() {
    const cep = formData.cep.replace(/\D/g, "");
    if (cep.length === 8) {
      // Simulação de busca de CEP
      setTimeout(() => {
        setFormData((prev) => ({
          ...prev,
          rua: "Rua Exemplo",
          bairro: "Centro",
          cidade: "São Paulo",
          estado: "SP",
        }));
      }, 500);
    }
  }

  function validateForm() {
    const newErrors: Record<string, string> = {};

    if (!formData.nome.trim()) newErrors.nome = "Nome é obrigatório";
    if (!formData.email.includes("@")) newErrors.email = "Email inválido";
    if (!formData.telefone) newErrors.telefone = "Telefone é obrigatório";
    if (!formData.cpf) newErrors.cpf = "CPF é obrigatório";
    if (!formData.cep) newErrors.cep = "CEP é obrigatório";
    if (!formData.rua) newErrors.rua = "Rua é obrigatória";
    if (!formData.numero) newErrors.numero = "Número é obrigatório";
    if (!formData.bairro) newErrors.bairro = "Bairro é obrigatório";
    if (!formData.cidade) newErrors.cidade = "Cidade é obrigatória";
    if (!formData.estado) newErrors.estado = "Estado é obrigatório";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (validateForm()) {
      setLoading(true);
      setTimeout(() => {
        onPlaceOrder({
          address: formData,
          paymentMethod,
          total,
        });
        setLoading(false);
      }, 2000);
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-7xl mx-auto px-4 py-8"
    >
      <button onClick={onBack} className="mb-6 text-green-400 hover:text-green-300 flex items-center gap-2">
        <ArrowLeft className="size-5" />
        Voltar
      </button>

      <h1 className="mb-8 bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
        Finalizar Compra
      </h1>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Form */}
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Dados Pessoais */}
            <div className="bg-gray-900/50 p-6 rounded-2xl border border-green-500/20">
              <h2 className="mb-4 text-green-400">Dados Pessoais</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <Input
                  label="Nome Completo"
                  value={formData.nome}
                  onChange={(v) => updateField("nome", v)}
                  error={errors.nome}
                  required
                />
                <Input
                  label="CPF"
                  value={formData.cpf}
                  onChange={(v) => updateField("cpf", v)}
                  error={errors.cpf}
                  required
                  placeholder="000.000.000-00"
                />
                <Input
                  label="Email"
                  type="email"
                  value={formData.email}
                  onChange={(v) => updateField("email", v)}
                  error={errors.email}
                  required
                />
                <Input
                  label="Telefone"
                  value={formData.telefone}
                  onChange={(v) => updateField("telefone", v)}
                  error={errors.telefone}
                  required
                  placeholder="(11) 99999-9999"
                />
              </div>
            </div>

            {/* Endereço */}
            <div className="bg-gray-900/50 p-6 rounded-2xl border border-green-500/20">
              <h2 className="mb-4 text-green-400">Endereço de Entrega</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <Input
                  label="CEP"
                  value={formData.cep}
                  onChange={(v) => updateField("cep", v)}
                  error={errors.cep}
                  required
                  placeholder="00000-000"
                />
                <div />
                <div className="md:col-span-2">
                  <Input
                    label="Rua"
                    value={formData.rua}
                    onChange={(v) => updateField("rua", v)}
                    error={errors.rua}
                    required
                  />
                </div>
                <Input
                  label="Número"
                  value={formData.numero}
                  onChange={(v) => updateField("numero", v)}
                  error={errors.numero}
                  required
                />
                <Input
                  label="Complemento"
                  value={formData.complemento}
                  onChange={(v) => updateField("complemento", v)}
                  placeholder="Opcional"
                />
                <Input
                  label="Bairro"
                  value={formData.bairro}
                  onChange={(v) => updateField("bairro", v)}
                  error={errors.bairro}
                  required
                />
                <div />
                <Input
                  label="Cidade"
                  value={formData.cidade}
                  onChange={(v) => updateField("cidade", v)}
                  error={errors.cidade}
                  required
                />
                <Input
                  label="Estado"
                  value={formData.estado}
                  onChange={(v) => updateField("estado", v)}
                  error={errors.estado}
                  required
                  placeholder="SP"
                />
              </div>
            </div>

            {/* Pagamento */}
            <div className="bg-gray-900/50 p-6 rounded-2xl border border-green-500/20">
              <h2 className="mb-4 text-green-400">Forma de Pagamento</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.02 }}
                  onClick={() => setPaymentMethod("pix")}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    paymentMethod === "pix"
                      ? "border-green-500 bg-green-500/10"
                      : "border-gray-700 bg-gray-800/50"
                  }`}
                >
                  <Wallet className="size-8 mx-auto mb-2 text-green-400" />
                  <p>PIX</p>
                  <p className="text-xs text-gray-400 mt-1">Aprovação instantânea</p>
                </motion.button>
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.02 }}
                  onClick={() => setPaymentMethod("card")}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    paymentMethod === "card"
                      ? "border-green-500 bg-green-500/10"
                      : "border-gray-700 bg-gray-800/50"
                  }`}
                >
                  <CreditCard className="size-8 mx-auto mb-2 text-green-400" />
                  <p>Cartão de Crédito</p>
                  <p className="text-xs text-gray-400 mt-1">Parcelamento disponível</p>
                </motion.button>
              </div>
            </div>

            <Button type="submit" loading={loading} className="w-full" size="lg">
              Finalizar Pedido - R$ {total.toFixed(2)}
            </Button>
          </form>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-gray-900/50 p-6 rounded-2xl border border-green-500/20 sticky top-24">
            <h2 className="mb-4 text-green-400">Resumo do Pedido</h2>
            <div className="space-y-4 mb-6">
              {cart.map((item) => (
                <div key={item.id} className="flex gap-3">
                  <img src={item.img} alt={item.nome} className="w-16 h-16 object-cover rounded-lg" />
                  <div className="flex-1">
                    <p className="text-sm">{item.nome}</p>
                    <p className="text-xs text-gray-400">Qtd: {item.quantidade}</p>
                    <p className="text-sm text-green-400">R$ {(item.preco * item.quantidade).toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t border-gray-700 pt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Subtotal</span>
                <span>R$ {subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Frete</span>
                <span className={frete === 0 ? "text-green-400" : ""}>
                  {frete === 0 ? "GRÁTIS" : `R$ ${frete.toFixed(2)}`}
                </span>
              </div>
              <div className="flex justify-between pt-2 border-t border-gray-700">
                <span>Total</span>
                <span className="bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
                  R$ {total.toFixed(2)}
                </span>
              </div>
            </div>
            {subtotal < 150 && (
              <p className="text-xs text-gray-400 mt-4 text-center">
                Faltam R$ {(150 - subtotal).toFixed(2)} para frete grátis
              </p>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
