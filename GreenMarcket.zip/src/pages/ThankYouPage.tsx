import React from "react";
import { motion } from "motion/react";
import { CheckCircle, Copy, Download } from "lucide-react";
import { Button } from "../components/Button";

interface Order {
  id: string;
  date: string;
  items: any[];
  total: number;
  status: string;
}

interface ThankYouPageProps {
  order: Order;
  onContinue: () => void;
}

export function ThankYouPage({ order, onContinue }: ThankYouPageProps) {
  const pixCode = "00020126580014BR.GOV.BCB.PIX0136" + order.id + "520400005303986540" + order.total.toFixed(2);

  function copyPixCode() {
    navigator.clipboard.writeText(pixCode);
    alert("Código PIX copiado!");
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-3xl mx-auto px-4 py-12 text-center"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", delay: 0.2 }}
        className="mb-8"
      >
        <CheckCircle className="size-24 text-green-400 mx-auto mb-4" />
        <h1 className="mb-4 bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
          Pedido Realizado com Sucesso!
        </h1>
        <p className="text-gray-400">
          Obrigado pela sua compra! Seu pedido foi registrado e está sendo processado.
        </p>
      </motion.div>

      {/* Order Info */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-gray-900/50 p-8 rounded-2xl border border-green-500/20 mb-8"
      >
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <div>
            <p className="text-sm text-gray-400 mb-1">Número do Pedido</p>
            <p className="text-green-400">{order.id}</p>
          </div>
          <div>
            <p className="text-sm text-gray-400 mb-1">Total</p>
            <p className="text-green-400">R$ {order.total.toFixed(2)}</p>
          </div>
        </div>

        {/* PIX Payment */}
        <div className="bg-black/30 p-6 rounded-xl border border-green-500/20">
          <h2 className="mb-4 text-green-400">Pagamento via PIX</h2>
          <p className="text-sm text-gray-400 mb-4">
            Escaneie o QR Code ou copie o código abaixo para realizar o pagamento
          </p>

          {/* QR Code Placeholder */}
          <div className="bg-white p-4 rounded-xl inline-block mb-4">
            <div className="w-48 h-48 bg-gray-200 flex items-center justify-center">
              <p className="text-gray-600 text-xs text-center">QR Code PIX<br />Demo</p>
            </div>
          </div>

          {/* PIX Code */}
          <div className="bg-gray-900 p-4 rounded-xl border border-gray-700 mb-4">
            <p className="text-xs text-gray-400 break-all font-mono">{pixCode}</p>
          </div>

          <div className="flex gap-3 justify-center">
            <Button onClick={copyPixCode} variant="outline">
              <Copy className="size-4" />
              Copiar Código
            </Button>
            <Button variant="ghost">
              <Download className="size-4" />
              Baixar QR Code
            </Button>
          </div>
        </div>
      </motion.div>

      {/* Next Steps */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-gray-900/50 p-6 rounded-2xl border border-green-500/20 mb-8"
      >
        <h3 className="mb-4 text-green-400">Próximos Passos</h3>
        <div className="text-left space-y-3 text-sm text-gray-400">
          <div className="flex gap-3">
            <div className="bg-green-500 text-white rounded-full size-6 flex items-center justify-center flex-shrink-0 text-xs">
              1
            </div>
            <p>Realize o pagamento via PIX usando o código ou QR Code acima</p>
          </div>
          <div className="flex gap-3">
            <div className="bg-green-500 text-white rounded-full size-6 flex items-center justify-center flex-shrink-0 text-xs">
              2
            </div>
            <p>Aguarde a confirmação do pagamento (geralmente instantâneo)</p>
          </div>
          <div className="flex gap-3">
            <div className="bg-green-500 text-white rounded-full size-6 flex items-center justify-center flex-shrink-0 text-xs">
              3
            </div>
            <p>Seu pedido será preparado e enviado em até 24 horas úteis</p>
          </div>
          <div className="flex gap-3">
            <div className="bg-green-500 text-white rounded-full size-6 flex items-center justify-center flex-shrink-0 text-xs">
              4
            </div>
            <p>Acompanhe o status do seu pedido no seu perfil</p>
          </div>
        </div>
      </motion.div>

      <Button onClick={onContinue} size="lg">
        Continuar Comprando
      </Button>

      <p className="text-xs text-gray-500 mt-6">
        Você receberá um email de confirmação com todos os detalhes do seu pedido.
      </p>
    </motion.div>
  );
}
