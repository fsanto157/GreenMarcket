import React, { useState } from "react";
import { motion } from "motion/react";
import { User, Package, MapPin, CreditCard, Settings } from "lucide-react";
import { Button } from "../components/Button";

interface UserProfile {
  name: string;
  email: string;
  phone: string;
  cpf: string;
}

interface Order {
  id: string;
  date: string;
  items: any[];
  total: number;
  status: "pending" | "paid" | "shipped" | "delivered";
}

interface ProfilePageProps {
  user: UserProfile;
  orders: Order[];
  onViewProduct: (product: any) => void;
}

export function ProfilePage({ user, orders, onViewProduct }: ProfilePageProps) {
  const [activeTab, setActiveTab] = useState<"orders" | "profile" | "addresses">("orders");

  const statusColors = {
    pending: "text-yellow-400",
    paid: "text-blue-400",
    shipped: "text-purple-400",
    delivered: "text-green-400",
  };

  const statusLabels = {
    pending: "Aguardando Pagamento",
    paid: "Pago",
    shipped: "Enviado",
    delivered: "Entregue",
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-7xl mx-auto px-4 py-8"
    >
      <h1 className="mb-8 bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
        Meu Perfil
      </h1>

      <div className="grid lg:grid-cols-4 gap-8">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="bg-gray-900/50 p-6 rounded-2xl border border-green-500/20">
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-gradient-to-r from-green-600 to-emerald-600 rounded-full mx-auto mb-3 flex items-center justify-center">
                <User className="size-10" />
              </div>
              <h3>{user.name}</h3>
              <p className="text-sm text-gray-400">{user.email}</p>
            </div>

            <nav className="space-y-2">
              <button
                onClick={() => setActiveTab("orders")}
                className={`w-full text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${
                  activeTab === "orders"
                    ? "bg-green-500/20 text-green-400 border border-green-500/30"
                    : "hover:bg-gray-800"
                }`}
              >
                <Package className="size-5" />
                Meus Pedidos
              </button>
              <button
                onClick={() => setActiveTab("profile")}
                className={`w-full text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${
                  activeTab === "profile"
                    ? "bg-green-500/20 text-green-400 border border-green-500/30"
                    : "hover:bg-gray-800"
                }`}
              >
                <Settings className="size-5" />
                Dados Pessoais
              </button>
              <button
                onClick={() => setActiveTab("addresses")}
                className={`w-full text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${
                  activeTab === "addresses"
                    ? "bg-green-500/20 text-green-400 border border-green-500/30"
                    : "hover:bg-gray-800"
                }`}
              >
                <MapPin className="size-5" />
                Endereços
              </button>
            </nav>
          </div>
        </div>

        {/* Content */}
        <div className="lg:col-span-3">
          {activeTab === "orders" && (
            <div>
              <h2 className="mb-6 text-green-400">Meus Pedidos</h2>
              {orders.length === 0 ? (
                <div className="bg-gray-900/50 p-12 rounded-2xl border border-green-500/20 text-center">
                  <Package className="size-16 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">Você ainda não fez nenhum pedido</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {orders.map((order) => (
                    <motion.div
                      key={order.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-gray-900/50 p-6 rounded-2xl border border-green-500/20"
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <p className="text-sm text-gray-400">Pedido #{order.id}</p>
                          <p className="text-xs text-gray-500">
                            {new Date(order.date).toLocaleDateString("pt-BR")}
                          </p>
                        </div>
                        <span className={`text-sm ${statusColors[order.status]}`}>
                          {statusLabels[order.status]}
                        </span>
                      </div>

                      <div className="space-y-3 mb-4">
                        {order.items.map((item) => (
                          <div key={item.id} className="flex gap-3">
                            <img
                              src={item.img}
                              alt={item.nome}
                              className="w-16 h-16 object-cover rounded-lg"
                            />
                            <div className="flex-1">
                              <p className="text-sm">{item.nome}</p>
                              <p className="text-xs text-gray-400">Qtd: {item.quantidade}</p>
                            </div>
                            <p className="text-sm text-green-400">
                              R$ {(item.preco * item.quantidade).toFixed(2)}
                            </p>
                          </div>
                        ))}
                      </div>

                      <div className="flex justify-between items-center pt-4 border-t border-gray-700">
                        <span>Total</span>
                        <span className="bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
                          R$ {order.total.toFixed(2)}
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === "profile" && (
            <div>
              <h2 className="mb-6 text-green-400">Dados Pessoais</h2>
              <div className="bg-gray-900/50 p-6 rounded-2xl border border-green-500/20">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-400">Nome Completo</label>
                    <p>{user.name}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Email</label>
                    <p>{user.email}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Telefone</label>
                    <p>{user.phone}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">CPF</label>
                    <p>{user.cpf}</p>
                  </div>
                </div>
                <Button className="mt-6" variant="outline">
                  Editar Dados
                </Button>
              </div>
            </div>
          )}

          {activeTab === "addresses" && (
            <div>
              <h2 className="mb-6 text-green-400">Meus Endereços</h2>
              <div className="bg-gray-900/50 p-12 rounded-2xl border border-green-500/20 text-center">
                <MapPin className="size-16 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400 mb-4">Nenhum endereço cadastrado</p>
                <Button variant="outline">Adicionar Endereço</Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
