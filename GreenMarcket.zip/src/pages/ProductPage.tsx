import React, { useState } from "react";
import { motion } from "motion/react";
import { Heart, Star, ArrowLeft, Package, Truck, ShieldCheck } from "lucide-react";
import { Button } from "../components/Button";
import { Produto } from "../App";

interface ProductPageProps {
  product: Produto;
  isInWishlist: boolean;
  onToggleWishlist: (id: number) => void;
  onAddToCart: (product: Produto) => void;
  onBack: () => void;
}

export function ProductPage({
  product,
  isInWishlist,
  onToggleWishlist,
  onAddToCart,
  onBack,
}: ProductPageProps) {
  const [selectedImage, setSelectedImage] = useState(0);
  const isOutOfStock = product.stock !== undefined && product.stock === 0;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-7xl mx-auto px-4 py-8"
    >
      <button onClick={onBack} className="mb-6 text-green-400 hover:text-green-300 flex items-center gap-2">
        <ArrowLeft className="size-5" />
        Voltar
      </button>

      <div className="grid md:grid-cols-2 gap-12">
        {/* Gallery */}
        <div>
          <motion.div
            layoutId={`product-${product.id}`}
            className="relative rounded-2xl overflow-hidden border border-green-500/20 mb-4 bg-gray-900"
          >
            {isOutOfStock && (
              <div className="absolute inset-0 bg-black/60 backdrop-blur-sm z-10 flex items-center justify-center">
                <div className="bg-red-500 text-white px-6 py-3 rounded-xl">
                  Produto Esgotado
                </div>
              </div>
            )}
            <img
              src={product.images[selectedImage]}
              alt={product.nome}
              className="w-full h-96 object-cover"
            />
          </motion.div>
          <div className="flex gap-3">
            {product.images.map((img, i) => (
              <motion.button
                key={i}
                whileHover={{ scale: 1.05 }}
                onClick={() => setSelectedImage(i)}
                className={`flex-1 rounded-xl overflow-hidden border-2 ${
                  selectedImage === i ? "border-green-500" : "border-gray-700"
                }`}
              >
                <img src={img} alt="" className="w-full h-20 object-cover" />
              </motion.button>
            ))}
          </div>
        </div>

        {/* Info */}
        <div>
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h1 className="mb-2">{product.nome}</h1>
              <div className="flex items-center gap-3 mb-2">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`size-5 ${
                        i < Math.floor(product.rating)
                          ? "fill-yellow-400 text-yellow-400"
                          : "text-gray-600"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-400">
                  {product.rating} ({product.reviews} avaliações)
                </span>
              </div>
              {product.sku && (
                <p className="text-sm text-gray-500">SKU: {product.sku}</p>
              )}
            </div>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => onToggleWishlist(product.id)}
              className="bg-gray-900 p-3 rounded-full border border-green-500/30"
            >
              <Heart
                className={`size-6 ${
                  isInWishlist ? "fill-red-500 text-red-500" : "text-gray-400"
                }`}
              />
            </motion.button>
          </div>

          <div className="mb-6">
            <span className="bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
              R$ {product.preco.toFixed(2)}
            </span>
          </div>

          {/* Stock */}
          {product.stock !== undefined && (
            <div className="mb-6">
              <p className={`text-sm ${product.stock > 0 ? "text-green-400" : "text-red-400"}`}>
                {product.stock > 0 ? `${product.stock} unidades disponíveis` : "Produto esgotado"}
              </p>
            </div>
          )}

          {product.thc !== "-" && (
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-900 p-4 rounded-xl border border-green-500/20">
                <div className="text-sm text-gray-400 mb-1">THC</div>
                <div className="text-green-400">{product.thc}</div>
              </div>
              <div className="bg-gray-900 p-4 rounded-xl border border-green-500/20">
                <div className="text-sm text-gray-400 mb-1">CBD</div>
                <div className="text-green-400">{product.cbd}</div>
              </div>
            </div>
          )}

          <div className="mb-6">
            <h3 className="mb-3">Descrição</h3>
            <p className="text-gray-400 leading-relaxed">{product.descricao}</p>
          </div>

          {/* Features */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="text-center p-4 bg-gray-900/50 rounded-xl border border-green-500/10">
              <Package className="size-6 text-green-400 mx-auto mb-2" />
              <p className="text-xs text-gray-400">Embalagem Discreta</p>
            </div>
            <div className="text-center p-4 bg-gray-900/50 rounded-xl border border-green-500/10">
              <Truck className="size-6 text-green-400 mx-auto mb-2" />
              <p className="text-xs text-gray-400">Entrega Rápida</p>
            </div>
            <div className="text-center p-4 bg-gray-900/50 rounded-xl border border-green-500/10">
              <ShieldCheck className="size-6 text-green-400 mx-auto mb-2" />
              <p className="text-xs text-gray-400">Qualidade Garantida</p>
            </div>
          </div>

          <Button onClick={() => onAddToCart(product)} disabled={isOutOfStock} className="w-full" size="lg">
            {isOutOfStock ? "Produto Esgotado" : "Adicionar ao Carrinho"}
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
