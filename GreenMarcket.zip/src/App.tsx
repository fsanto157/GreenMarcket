import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { CartSidebar } from "./components/CartSidebar";
import { HomePage } from "./pages/HomePage";
import { ProductPage } from "./pages/ProductPage";
import { CheckoutPage } from "./pages/CheckoutPage";
import { ThankYouPage } from "./pages/ThankYouPage";
import { ProfilePage } from "./pages/ProfilePage";
import { LoginPage } from "./pages/LoginPage";

// Import product images
import florImage from "figma:asset/ec663d5509b81b635ea09c40ae033c527d498afc.png";
import bongImage from "figma:asset/a7d91a86c4073bca4ea13303676f925fd79c704b.png";
import cbdOilImage from "figma:asset/059b20f5051966f0010e7d872aa4c68c75bc145b.png";
import delta8Image from "figma:asset/0615e3a048241a285581eaf29a8d051f156752d1.png";
import gummiesImage from "figma:asset/05c3ceafa50ee1f62ceea30fc60736e1e2ed3fe6.png";
import vapeImage from "figma:asset/1336d0f369034e87707ecdb26578a9a3a4fe1521.png";
import sedaImage from "figma:asset/8975e821116d0b8bbe02834a44bea9c5c28e3ca7.png";
import grinderImage from "figma:asset/8ece6d9c63d9f173fb4f90be387cf0b978ccbd50.png";

export interface Produto {
  id: number;
  nome: string;
  preco: number;
  categoria: string;
  img: string;
  images: string[];
  descricao: string;
  rating: number;
  reviews: number;
  thc: string;
  cbd: string;
  stock?: number;
  sku?: string;
}

interface CartItem extends Produto {
  quantidade: number;
}

interface User {
  name: string;
  email: string;
  phone: string;
  cpf: string;
}

interface Order {
  id: string;
  date: string;
  items: CartItem[];
  total: number;
  status: "pending" | "paid" | "shipped" | "delivered";
  shippingAddress: {
    cep: string;
    rua: string;
    numero: string;
    complemento: string;
    bairro: string;
    cidade: string;
    estado: string;
  };
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>("home");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Produto | null>(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [lastOrder, setLastOrder] = useState<Order | null>(null);

  const produtos: Produto[] = [
    {
      id: 1,
      nome: "Flor Premium - OG Kush",
      preco: 89.9,
      categoria: "flores",
      img: florImage,
      images: [
        florImage,
        "https://images.unsplash.com/photo-1612893125432-6f61c3a6f6b4?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1605735974855-891bb04d75ff?auto=format&fit=crop&w=600&q=80",
      ],
      descricao: "Flor premium cultivada indoor com altíssima qualidade. Aroma intenso de pinho e terra, efeito relaxante e equilibrado. Perfeita para uso noturno.",
      rating: 4.8,
      reviews: 127,
      thc: "22-25%",
      cbd: "<1%",
      stock: 15,
      sku: "FLR-001",
    },
    {
      id: 2,
      nome: "Óleo CBD Premium - 30ml",
      preco: 149.9,
      categoria: "oleos",
      img: cbdOilImage,
      images: [
        cbdOilImage,
        "https://images.unsplash.com/photo-1611689037241-d8dfe4280f2e?auto=format&fit=crop&w=600&q=80",
      ],
      descricao: "Óleo de CBD full spectrum 1500mg. Extração por CO2 supercrítico, sabor natural. Ideal para ansiedade, sono e dores crônicas.",
      rating: 4.9,
      reviews: 342,
      thc: "<0.3%",
      cbd: "1500mg",
      stock: 28,
      sku: "OIL-002",
    },
    {
      id: 3,
      nome: "Vape Pen Premium - Green Edition",
      preco: 139.9,
      categoria: "vaporizadores",
      img: vapeImage,
      images: [
        vapeImage,
        "https://images.unsplash.com/photo-1585559604959-3a5a5c6be798?auto=format&fit=crop&w=600&q=80",
      ],
      descricao: "Vape pen recarregável premium com bateria de longa duração. Design ergonômico e discreto. 3 níveis de temperatura ajustáveis.",
      rating: 4.7,
      reviews: 189,
      thc: "Variable",
      cbd: "Variable",
      stock: 12,
      sku: "VAP-003",
    },
    {
      id: 4,
      nome: "Bong de Vidro Premium",
      preco: 189.9,
      categoria: "acessorios",
      img: bongImage,
      images: [
        bongImage,
        "https://images.unsplash.com/photo-1583947581924-860bda6a26df?auto=format&fit=crop&w=600&q=80",
      ],
      descricao: "Bong de vidro borosilicato premium com percolador duplo. Altura 35cm, base estável. Proporciona hits suaves e refrescantes.",
      rating: 4.8,
      reviews: 156,
      thc: "-",
      cbd: "-",
      stock: 8,
      sku: "BNG-004",
    },
    {
      id: 5,
      nome: "Pote Hermético Premium",
      preco: 49.9,
      categoria: "acessorios",
      img: florImage,
      images: [florImage],
      descricao: "Pote hermético de vidro com vedação UV. Mantém frescor e aroma por meses. Capacidade 100ml, design elegante com logo em dourado.",
      rating: 4.9,
      reviews: 278,
      thc: "-",
      cbd: "-",
      stock: 45,
      sku: "POT-005",
    },
    {
      id: 6,
      nome: "Óleo Delta-8 THC Premium - 30ml",
      preco: 169.9,
      categoria: "oleos",
      img: delta8Image,
      images: [
        delta8Image,
        "https://images.unsplash.com/photo-1611689037241-d8dfe4280f2e?auto=format&fit=crop&w=600&q=80",
      ],
      descricao: "Óleo de Delta-8 THC full spectrum 1500mg. Extração por CO2 supercrítico, sabor natural. Efeito suave e relaxante.",
      rating: 4.9,
      reviews: 342,
      thc: "1500mg",
      cbd: "<0.3%",
      stock: 0,
      sku: "D8-006",
    },
    {
      id: 7,
      nome: "Gummies Premium - Ursinhos CBD",
      preco: 79.9,
      categoria: "comestiveis",
      img: gummiesImage,
      images: [gummiesImage],
      descricao: "Gummies sabor frutas variadas com 10mg de CBD cada. Pacote com 30 unidades. Sem açúcar, vegano, sabores naturais.",
      rating: 4.6,
      reviews: 423,
      thc: "0%",
      cbd: "10mg/un",
      stock: 56,
      sku: "GMM-007",
    },
    {
      id: 8,
      nome: "Grinder 4 Partes Alumínio",
      preco: 39.9,
      categoria: "acessorios",
      img: grinderImage,
      images: [grinderImage],
      descricao: "Grinder profissional em alumínio anodizado com 4 partes. Dentes diamantados, tela para kief e ímã forte.",
      rating: 4.8,
      reviews: 312,
      thc: "-",
      cbd: "-",
      stock: 34,
      sku: "GRN-008",
    },
    {
      id: 9,
      nome: "Seda Ultra Fina King Size",
      preco: 9.9,
      categoria: "acessorios",
      img: sedaImage,
      images: [sedaImage],
      descricao: "Seda ultra fina de origem francesa, queima lenta e uniforme. Papel natural sem químicos. 32 folhas king size.",
      rating: 4.7,
      reviews: 456,
      thc: "-",
      cbd: "-",
      stock: 120,
      sku: "SED-009",
    },
  ];

  function addToCart(produto: Produto) {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === produto.id);
      if (existing) {
        return prev.map((item) =>
          item.id === produto.id ? { ...item, quantidade: item.quantidade + 1 } : item
        );
      }
      return [...prev, { ...produto, quantidade: 1 }];
    });
    setCartOpen(true);
  }

  function updateQuantity(id: number, delta: number) {
    setCart((prev) =>
      prev
        .map((item) =>
          item.id === id ? { ...item, quantidade: item.quantidade + delta } : item
        )
        .filter((item) => item.quantidade > 0)
    );
  }

  function toggleWishlist(id: number) {
    setWishlist((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  }

  function navigateTo(page: string) {
    setCurrentPage(page);
    setSelectedProduct(null);
    window.scrollTo(0, 0);
  }

  function viewProduct(product: Produto) {
    setSelectedProduct(product);
    setCurrentPage("produto");
    window.scrollTo(0, 0);
  }

  function handleCheckout() {
    if (!currentUser) {
      navigateTo("login");
      return;
    }
    setCartOpen(false);
    navigateTo("checkout");
  }

  function handlePlaceOrder(orderData: any) {
    const newOrder: Order = {
      id: `ORD-${Date.now()}`,
      date: new Date().toISOString(),
      items: [...cart],
      total: cart.reduce((sum, item) => sum + item.preco * item.quantidade, 0),
      status: "pending",
      shippingAddress: orderData.address,
    };

    setOrders((prev) => [newOrder, ...prev]);
    setLastOrder(newOrder);
    setCart([]);
    navigateTo("obrigado");
  }

  function handleLogin(userData: User) {
    setCurrentUser(userData);
    navigateTo("home");
  }

  function handleLogout() {
    setCurrentUser(null);
    setOrders([]);
    navigateTo("home");
  }

  const totalItems = cart.reduce((sum, item) => sum + item.quantidade, 0);

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <Header
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        cartItemsCount={totalItems}
        wishlistCount={wishlist.length}
        onCartClick={() => setCartOpen(true)}
        onWishlistClick={() => {
          /* TODO: Wishlist modal */
        }}
        onNavigate={navigateTo}
        currentUser={currentUser}
        onLogout={handleLogout}
      />

      <main className="flex-1">
        <AnimatePresence mode="wait">
          {currentPage === "home" && (
            <HomePage
              key="home"
              produtos={produtos}
              searchTerm={searchTerm}
              wishlist={wishlist}
              onToggleWishlist={toggleWishlist}
              onAddToCart={addToCart}
              onViewProduct={viewProduct}
            />
          )}

          {currentPage === "produto" && selectedProduct && (
            <ProductPage
              key="produto"
              product={selectedProduct}
              isInWishlist={wishlist.includes(selectedProduct.id)}
              onToggleWishlist={toggleWishlist}
              onAddToCart={addToCart}
              onBack={() => navigateTo("home")}
            />
          )}

          {currentPage === "checkout" && (
            <CheckoutPage
              key="checkout"
              cart={cart}
              onPlaceOrder={handlePlaceOrder}
              onBack={() => navigateTo("home")}
            />
          )}

          {currentPage === "obrigado" && lastOrder && (
            <ThankYouPage key="obrigado" order={lastOrder} onContinue={() => navigateTo("home")} />
          )}

          {currentPage === "perfil" && currentUser && (
            <ProfilePage
              key="perfil"
              user={currentUser}
              orders={orders}
              onViewProduct={viewProduct}
            />
          )}

          {currentPage === "login" && (
            <LoginPage key="login" onLogin={handleLogin} onBack={() => navigateTo("home")} />
          )}
        </AnimatePresence>
      </main>

      <Footer />

      <CartSidebar
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        onUpdateQuantity={updateQuantity}
        onCheckout={handleCheckout}
      />
    </div>
  );
}
